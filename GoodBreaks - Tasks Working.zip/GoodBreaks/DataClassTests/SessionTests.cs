﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GoodBreaks;
using NUnit.Framework;

namespace DataClassTests
{
    [TestFixture]
    class SessionTests
    {
        [Test]
        public void Constructor()
        {

        }
            
        [Test]
        public void AddSurferAddsAnItem()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            Assert.AreEqual(1, testSession.SurfersAtSession.Count); 
        }

        [Test]
        public void AddSurferAddsCorrectSurferReferenceToSession()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            List<Surfer> surfers = testSession.SurfersAtSession as List<Surfer>;
            Assert.True(surfers.Contains(testSurfer));
        }

        [Test]
        public void AddSurferAddsCorrectSessionReferenceToSurfer()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            List<Session> sessions = testSurfer.Sessions as List<Session>;
            Assert.True(sessions.Contains(testSession)); 
        }

        [Test]
        public void RemoveSurferRemovesAnItem()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            testSession.RemoveSurfer(testSurfer); 
            Assert.AreEqual(0, testSession.SurfersAtSession.Count);
        }

        [Test]
        public void RemoveSurferRemovesCorrectSurferReferenceFromSession()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            testSession.RemoveSurfer(testSurfer);
            List<Surfer> surfers = testSession.SurfersAtSession as List<Surfer>;
            Assert.False(surfers.Contains(testSurfer)); 
        }

        [Test]
        public void RemoveSurferRemovesCorrectSessionReferenceFromSurfer()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "first", surferLastName: "last");
            Session testSession = new Session();
            testSession.AddSurfer(testSurfer);
            testSession.RemoveSurfer(testSurfer);
            List<Session> sessions = testSurfer.Sessions as List<Session>;
            Assert.False(sessions.Contains(testSession)); 
        }
    }
}
