﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace GoodBreaksWP7.Utilities
{
    public static class TaskHelper<T> where T : class
    {
        //methods
        public static Task<List<T>> InvokeTaskMagic(HttpWebRequest request)
        {
            var resultList = new List<T>();

            Task<WebResponse> task1 = Task<WebResponse>.Factory.FromAsync(
                (callback, o) => ((HttpWebRequest)o).BeginGetResponse(callback, o)
                , result => ((HttpWebRequest)result.AsyncState).EndGetResponse(result)
                , request);

            return task1.ContinueWith<List<T>>((antecedent) =>
            {
                if (antecedent.IsFaulted)
                {
                    return new List<T>();
                } 

                WebResponse webResponse;
                try
                {
                    webResponse = task1.Result;
                }
                catch (AggregateException ex1)
                {
                    throw ex1.InnerException;
                }

                string responseString;

                using (var response = (HttpWebResponse)webResponse)
                {
                    using (Stream streamResponse = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(streamResponse);
                        responseString = reader.ReadToEnd();
                        reader.Close();
                    }
                }

                if (responseString != null)
                {
                    return JsonConvert.DeserializeObject<List<T>>(responseString);
                }
                else
                {
                    return new List<T>();
                }
            }); 
        }
    }
}
