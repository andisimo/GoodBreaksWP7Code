﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace GoodBreaksWP7.Utilities
{
    internal static class CommentApiHelper
    {
        //methods
        public static HttpWebRequest GetOneComment(string commentCompleteKey)
        {
            var commentKeys = KeyHelper.ParseCompleteKey(commentCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("commentPK", commentKeys["region"]);
            args.Add("commentRK", commentKeys["id"]);

            var request = ConnectionHelper.GET("comments", args);
            return request;
        }

        public static HttpWebRequest GetCommentsByMe(string commenterCompleteKey)
        {
            var commenterKeys = KeyHelper.ParseCompleteKey(commenterCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("commenterPK", commenterKeys["region"]);
            args.Add("commenterRK", commenterKeys["id"]);

            var request = ConnectionHelper.GET("collectionofcommentsbyme", args);
            return request;
        }

        public static HttpWebRequest GetCommentsAboutMe(string aboutObjectCompleteKey)
        {
            var aboutObjectKeys = KeyHelper.ParseCompleteKey(aboutObjectCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("aboutObjectPK", aboutObjectKeys["region"]);
            args.Add("aboutObjectRK", aboutObjectKeys["id"]);

            var request = ConnectionHelper.GET("collectionofcommentsaboutme", args);
            return request;
        }
    }
}
