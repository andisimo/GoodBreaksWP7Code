﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Services.Common;
using Newtonsoft.Json;

namespace GoodBreaksClasses
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Surfer : ICommentable
    {
        //fields
        private List<SurfBoard> _surfBoards = new List<SurfBoard>();
        private List<Session> _sessions = new List<Session>();
        private SortedCommentList _commentsAboutMe = new SortedCommentList();
        private SortedCommentList _commentsByMe = new SortedCommentList();

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NickName { get; set; }
        public string FullName { get; set; }
        public string Description { get; set; }
        public string ImageLocation { get; set; }
        public string Region { get; set; }

        //collection properties
        [JsonIgnore]
        public ICollection<SurfBoard> SurfBoards
        {
            get { return _surfBoards; }
            set { _surfBoards = value as List<SurfBoard>; }
        }

        [JsonIgnore]
        public ICollection<Session> Sessions
        {
            get { return _sessions; }
            set { _sessions = value as List<Session>; }
        }

        [JsonIgnore]
        public SortedCommentList CommentsAboutMe
        {
            get { return _commentsAboutMe; }
            set
            {
                if (_commentsAboutMe != value)
                {
                    _commentsAboutMe = value;
                    NotifyPropertyChanged("CommentsAboutMe");
                }
            }
        }

        [JsonIgnore]
        public SortedCommentList CommentsByMe
        {
            get { return _commentsByMe; }
            set
            {
                if (_commentsByMe != value)
                {
                    _commentsByMe = value;
                    NotifyPropertyChanged("CommentsByMe");
                }
            }
        }

        //constructors
        public Surfer()
        { }

        public Surfer(string surferFirstName, string surferLastName, string surferRegion)
        {
            FirstName = surferFirstName;
            LastName = surferLastName;
            FullName = surferFirstName + " " + surferLastName;
            Region = surferRegion;
            PartitionKey = Region;
            RowKey = "sur-" + Guid.NewGuid().ToString();
        }

        //methods
        public void AddBoard(SurfBoard board)
        {
            SurfBoards.Add(board);
        }

        public void RemoveBoard(SurfBoard board)
        {
            SurfBoards.Remove(board);
        }

        public void JoinSession(Session sessionToJoin)
        {
            Sessions.Add(sessionToJoin);
            sessionToJoin.AddSurfer(this);
        }

        public void UndoJoindSession(Session sessionToUndoJoin)
        {
            Sessions.Remove(sessionToUndoJoin);
            sessionToUndoJoin.RemoveSurfer(this);
        }

        public void AddComment(Comment comment)
        {
            CommentsAboutMe.Comments.Add(comment);
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            var handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
