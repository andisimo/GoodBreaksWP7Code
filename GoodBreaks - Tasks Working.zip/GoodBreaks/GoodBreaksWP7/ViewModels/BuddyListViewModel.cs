﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyListViewModel : INotifyPropertyChanged
    {
        //private fields
        private ObservableCollection<BuddyViewModel> _surfers = new ObservableCollection<BuddyViewModel>();
        private int _currentSelectedIndex;

        //public properties
        public ObservableCollection<BuddyViewModel> BuddyVMs
        {
            get { return _surfers; }
            set
            {
                if (_surfers != value)
                {
                    _surfers = value;
                    NotifyPropertyChanged("Surfers");
                }
            }
        }

        public bool IsDataLoaded { get; private set; }

        //methods
        public void LoadData()
        {
            var args = new Dictionary<string, string>();
            args.Add("surferPK", App.UserVm.LoggedInSurfer.PartitionKey);
            args.Add("surferRK", App.UserVm.LoggedInSurfer.RowKey);
            var request = ConnectionHelper.GET("collectionofbuddies", args);

            Task<WebResponse> task1 = Task<WebResponse>.Factory.FromAsync(
                (callback, o) => ((HttpWebRequest)o).BeginGetResponse(callback, o)
                , result => ((HttpWebRequest)result.AsyncState).EndGetResponse(result)
                , request);  

            task1.ContinueWith((antecedent) =>
            {
                WebResponse webResponse = task1.Result;
                string responseString;

                using (var response = (HttpWebResponse)webResponse)
                {
                    using (Stream streamResponse = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(streamResponse);
                        responseString = reader.ReadToEnd();
                        reader.Close();
                    }
                }

                var surferList = new List<Surfer>();
                if (responseString != null)
                {
                    surferList = JsonConvert.DeserializeObject<List<Surfer>>(responseString);
                    
                    UIThread.Invoke(() =>
                    {
                        foreach (Surfer s in surferList)
                        {
                            this.BuddyVMs.Add(new BuddyViewModel(s));
                        }
                    });
                }

                this.IsDataLoaded = true;
            });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
