﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GoodBreaksTypes;
using System.Collections.Generic;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyViewModel : Surfer
    {
        //properties
        public List<Comment> AllComments = new List<Comment>();
        

        //constructor
        public BuddyViewModel()
        {
            //combine two comment properties
            List<Comment> unsortedComments = CommentsAboutMe.Comments as List<Comment>;
            unsortedComments.AddRange(CommentsByMe.Comments);

            //Sort combined list of comments
            SortedCommentList sortedComments = new SortedCommentList(unsortedComments);
            AllComments = sortedComments.Comments as List<Comment>;
        }
    }
}
