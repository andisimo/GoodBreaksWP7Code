﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyListViewModel : INotifyPropertyChanged
    {
        //private fields
        private ObservableCollection<BuddyViewModel> _surfers = new ObservableCollection<BuddyViewModel>();
        private int _currentSelectedIndex;

        //public properties
        public ObservableCollection<BuddyViewModel> Surfers
        {
            get { return _surfers; }
            set
            {
                if (_surfers != value)
                {
                    _surfers = value;
                    NotifyPropertyChanged("Surfers");
                }
            }
        }

        public bool IsDataLoaded { get; private set; }

        //methods
        public void LoadData()
        {
            var args = new Dictionary<string, string>();
            args.Add("surferPK", App.UserVm.LoggedInSurfer.PartitionKey);
            args.Add("surferRK", App.UserVm.LoggedInSurfer.RowKey);
            var connectionHelper = new ConnectionHelper();
            var request = connectionHelper.GET("collectionofbuddies", args);

            var taskHelper = new TaskHelper();
            var task1 = taskHelper.InvokeTaskMagic(request);

            task1.ContinueWith((antecedent) =>
            {
                WebResponse webResponse = task1.Result;
                string responseString;

                using (var response = (HttpWebResponse)webResponse)
                {
                    using (Stream streamResponse = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(streamResponse);
                        responseString = reader.ReadToEnd();
                        reader.Close();
                    }
                }

                var surferList = new List<Surfer>();
                if (responseString != null)
                {
                    surferList = JsonConvert.DeserializeObject<List<Surfer>>(responseString);
                    
                    UIThread.Invoke(() =>
                    {
                        foreach (Surfer s in surferList)
                        {
                            this.Surfers.Add(s as BuddyViewModel);
                        }
                    });
                }

                this.IsDataLoaded = true;
            });
        }

        public void GetCollectionsForCurrent(int index)
        {
            _currentSelectedIndex = index;
            GetSessionsForCurrent();
            GetCommentsAboutForCurrent();
            GetCommentsByForCurrent();
        }

        public void GetSessionsForCurrent()
        {
            Surfer surfer = this.Surfers[_currentSelectedIndex];
            var args = new Dictionary<string, string>();
            args.Add("surferPK", surfer.PartitionKey);
            args.Add("surferRK", surfer.RowKey);
            var connectionHelper = new ConnectionHelper();
            var request = connectionHelper.GET("collectionofsessions", args);

            Task<WebResponse> task1 = Task<WebResponse>.Factory.FromAsync(
                (callback, o) => ((HttpWebRequest)o).BeginGetResponse(callback, o)
                , result => ((HttpWebRequest)result.AsyncState).EndGetResponse(result)
                , request); 

            task1.ContinueWith((antecedent) =>
                {
                    //if (antecedent.IsFaulted)
                    WebResponse webResponse;
                    try
                    {
                        webResponse = task1.Result;
                    }
                    catch (AggregateException ex1)
                    {
                        throw ex1;
                    }

                    string responseString;

                    using (var response = (HttpWebResponse)webResponse)
                    {
                        using (Stream streamResponse = response.GetResponseStream())
                        {
                            StreamReader reader = new StreamReader(streamResponse);
                            responseString = reader.ReadToEnd();
                            reader.Close();
                        }
                    }

                    var sessionList = new List<Session>();
                    if (responseString != null)
                    {
                        sessionList = JsonConvert.DeserializeObject<List<Session>>(responseString);

                        UIThread.Invoke(() =>
                        {
                            this.Surfers[_currentSelectedIndex].Sessions.Clear();
                            foreach (Session s in sessionList)
                            {
                                this.Surfers[_currentSelectedIndex].Sessions.Add(s);
                            }
                        });
                    }
                });
        }

        private void GetCommentsAboutForCurrent()
        {
            Surfer surfer = this.Surfers[_currentSelectedIndex];
            var args = new Dictionary<string, string>();
            args.Add("aboutObjectPK", surfer.PartitionKey);
            args.Add("aboutObjectRK", surfer.RowKey); 

            var connectionHelper = new ConnectionHelper();
            var request = connectionHelper.GET("collectionofcommentsaboutme", args);

            var taskHelper = new TaskHelper();
            var task1 = taskHelper.InvokeTaskMagic(request);

            task1.ContinueWith((antecedent) =>
            {
                WebResponse webResponse;
                try
                {
                    webResponse = task1.Result;
                }
                catch (AggregateException ex1)
                {
                    throw ex1;
                }

                string responseString;

                using (var response = (HttpWebResponse)webResponse)
                {
                    using (Stream streamResponse = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(streamResponse);
                        responseString = reader.ReadToEnd();
                        reader.Close();
                    }
                }

                var commentList = new List<Comment>();
                if (responseString != null)
                {
                    commentList = JsonConvert.DeserializeObject<List<Comment>>(responseString);

                    UIThread.Invoke(() =>
                    {
                        this.Surfers[_currentSelectedIndex].CommentsAboutMe.Comments.Clear();
                        foreach (Comment c in commentList)
                        {
                            this.Surfers[_currentSelectedIndex].CommentsAboutMe.Add(c);
                        }
                    });
                }
            });
        }

        private void GetCommentsByForCurrent()
        {
            Surfer surfer = this.Surfers[_currentSelectedIndex];
            var args = new Dictionary<string, string>();
            args.Add("commenterPK", surfer.PartitionKey);
            args.Add("commenterRK", surfer.RowKey);

            var connectionHelper = new ConnectionHelper();
            var request = connectionHelper.GET("collectionofcommentsbyme", args);

            var taskHelper = new TaskHelper();
            var task1 = taskHelper.InvokeTaskMagic(request);

            task1.ContinueWith((antecedent) =>
            {
                WebResponse webResponse;
                try
                {
                    webResponse = task1.Result;
                }
                catch (AggregateException ex1)
                {
                    throw ex1;
                }

                string responseString;

                using (var response = (HttpWebResponse)webResponse)
                {
                    using (Stream streamResponse = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(streamResponse);
                        responseString = reader.ReadToEnd();
                        reader.Close();
                    }
                }

                var commentList = new List<Comment>();
                if (responseString != null)
                {
                    commentList = JsonConvert.DeserializeObject<List<Comment>>(responseString);

                    UIThread.Invoke(() =>
                    {
                        this.Surfers[_currentSelectedIndex].CommentsByMe.Comments.Clear();
                        foreach (Comment c in commentList)
                        {
                            this.Surfers[_currentSelectedIndex].CommentsByMe.Add(c);
                        }
                    });
                }
            });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
