﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.IO;
using GoodBreaksTypes;
using Newtonsoft.Json;

namespace GoodBreaksWP7.Utilities
{
    public class TaskHelper
    {
        //public properties

        //constructors

        //methods
        public Task<WebResponse> InvokeTaskMagic(HttpWebRequest request)
        {
            //Couldn't have continuation task in here, because it created
            //a race condition, where the main thread would go and try to 
            //populate the VM collection before the task in this class could
            //complete. We had to let the main thread populate the view to keep
            //this code type agnostic. Solution: refactor this so they can pass
            //in a Func<> that defines the method for populating the view, get that
            //whole thing totally out of the ViewModel code that starts this task. 
            Task<WebResponse> task1 = Task<WebResponse>.Factory.FromAsync(
                (callback, o) => ((HttpWebRequest)o).BeginGetResponse(callback, o)
                , result => ((HttpWebRequest)result.AsyncState).EndGetResponse(result)
                , request);

            return task1;
        }
    }
}
