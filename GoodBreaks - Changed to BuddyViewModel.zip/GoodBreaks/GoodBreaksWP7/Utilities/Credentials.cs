﻿

namespace GoodBreaksWP7.Utilities
{
    public class Credentials
    {
        //public properties
        public string base64Realm { get; set; }

        //constructors
        public Credentials()
        {
            string HashedPassword = (App.UserVm.Salt + App.UserVm.Password).ToSHA1();

            byte[] base64Byte = System.Text.UTF8Encoding.UTF8.GetBytes(App.UserVm.UserName + ":" + HashedPassword);
            base64Realm = System.Convert.ToBase64String(base64Byte);
        }
    }
}
