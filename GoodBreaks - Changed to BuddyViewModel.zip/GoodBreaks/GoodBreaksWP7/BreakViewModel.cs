﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using GoodBreaksWP7.Models;

namespace GoodBreaksWP7.ViewModels
{
    public class BreakViewModel
    {
        private Break _breakProperty;

        public Break BreakProperty
        {
            get { return _breakProperty; }
            set
            {
                if (_breakProperty != value)
                {
                    _breakProperty = value;
                    NotifyPropertyChanged("BreakProperty");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
