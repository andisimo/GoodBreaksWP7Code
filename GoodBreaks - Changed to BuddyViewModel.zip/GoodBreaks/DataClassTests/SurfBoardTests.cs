﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using GoodBreaks;

namespace DataClassTests
{
    [TestFixture]
    class SurfBoardTests
    {
        [Test]
        public void Constructor()
        {
            SurfBoard testBoard = new SurfBoard(name: "name0");    
        }

        [Test]
        public void EqualsTrue()
        {
            SurfBoard testBoard1 = new SurfBoard(name: "name0");
            SurfBoard testBoard2 = testBoard1; 
            Assert.IsTrue(testBoard1.Equals(testBoard2));
        }

        [Test]
        public void EqualsFalse()
        {
            SurfBoard testBoard1 = new SurfBoard(name: "name0");
            SurfBoard testBoard2 = new SurfBoard(name: "name0");
            Assert.IsFalse(testBoard1.Equals(testBoard2));
        }
    }
}
