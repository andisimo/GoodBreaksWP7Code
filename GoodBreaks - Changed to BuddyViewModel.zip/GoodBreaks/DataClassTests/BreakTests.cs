﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using GoodBreaks;

namespace DataClassTests
{
    [TestFixture]
    public class BreakTests
    {
        [Test]
        public void Constructor()
        { 
            Break testBreak = new GoodBreaks.Break("Salt Creek", 100.1111111111, 200.222222222);

            Assert.NotNull(testBreak);
            Assert.AreEqual("Salt Creek", testBreak.Name);
            Assert.AreEqual(100.1111111111, testBreak.Latitude);
            Assert.AreEqual(200.222222222, testBreak.Longitude);
        }
    }
}
