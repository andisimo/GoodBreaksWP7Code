﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;
using GoodBreaksWP7.ViewModels;

namespace GoodBreaksWP7
{
    public partial class BreakView : PhoneApplicationPage
    {
        // Constructor
        public BreakView()
        {
            InitializeComponent();
        }

        private void HomeViewPanoramaLoaded(object sender, RoutedEventArgs e)
        {
            App.BreakListVm = new BreakListViewModel();
            App.BuddyListVm = new BuddyListViewModel();

            if (!App.BreakListVm.IsDataLoaded)
            {
                App.BreakListVm.LoadData();
            }

            if (!App.BuddyListVm.IsDataLoaded)
            {
                App.BuddyListVm.LoadData();
            }

            var panorama = sender as Panorama;
            if (panorama != null)
            {
                var breaksItem = panorama.Items[0] as PanoramaItem;
                if (breaksItem != null) breaksItem.DataContext = App.BreakListVm;
            }

            if (panorama != null)
            {
                var buddyItem = panorama.Items[1] as PanoramaItem;
                if (buddyItem != null) buddyItem.DataContext = App.BuddyListVm;
            }
        }

        private void BreaksListBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox thisListBox = sender as ListBox;
            if (thisListBox.SelectedIndex == -1)
            {
                return; 
            }

            NavigationService.Navigate(new Uri("/BreakView.xaml?selectedItem=" + thisListBox.SelectedIndex, UriKind.Relative));

            thisListBox.SelectedIndex = -1;
        }

        private void BuddiesListBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var thisListBox = sender as ListBox;
            if (thisListBox != null && thisListBox.SelectedIndex == -1)
            {
                return;
            }

            NavigationService.Navigate(new Uri("/BuddyView.xaml?selectedItem=" + thisListBox.SelectedIndex, UriKind.Relative));

            thisListBox.SelectedIndex = -1; 
        }
    }
}