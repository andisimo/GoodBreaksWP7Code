﻿using System;
using System.ComponentModel;
using System.Collections.ObjectModel;
using GoodBreaksClasses;

namespace GoodBreaksWP7.ViewModels
{
    public class BreakListViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Break> _breaks = new ObservableCollection<Break>();
        public ObservableCollection<Break> Breaks
        {
            get { return _breaks; }
            set
            {
                if (_breaks != value)
                {
                    _breaks = value;
                    NotifyPropertyChanged("Breaks"); 
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool IsDataLoaded { get; private set; }

        public void LoadData()
        {
            #region Sample Data
            ////Load Break Data
            //Break break1 = new Break("Trails", 33.4035084, -117.61002, "USWC");
            //Break break2 = new Break("Uppers", 33.386339, -117.597063, "USWC");
            //Break break3 = new Break("San Clemente Pier", 33.419631, -117.620822, "USWC");
            //Breaks.Add(break1);
            //Breaks.Add(break2);
            //Breaks.Add(break3);

            //Load Comment Data
            //Surfer surfer1 = new Surfer("Wingnut", "", "USWC");
            //surfer1.ImageLocation = "imageWingnut.jpg";

            //Surfer surfer2 = new Surfer("Pat", "Oconnell", "USWC");
            //surfer2.ImageLocation = "imagePat.jpg";

            //Comment comment1 = new Comment("I love Trails - just be careful walking down the cliffs",
            //    surfer1, break1);
            //comment1.CommentDateTime = new DateTime(2000, 01, 01);

            //Comment comment2 = new Comment("Last Saturday at Trails the surf was awesome! Full pipe ride!",
            //    surfer2, break1);
            //comment2.CommentDateTime = new DateTime(2001, 01, 01);

            //Comment comment6 = new Comment("This is a nice laid-back break. I love the pier.",
            //    surfer2, break3);
            //comment6.CommentDateTime = new DateTime(2005, 01, 01);

            //Comment comment4 = new Comment("That's bogus man. You can't make up rules!",
            //    surfer2, break2);
            //comment4.CommentDateTime = new DateTime(2003, 01, 01);

            //Comment comment5 = new Comment("Not my rules - those are the rules of the waves",
            //    surfer1, break2);
            //comment5.CommentDateTime = new DateTime(2004, 01, 01);

            //Comment comment3 = new Comment("Pros only here. No amateurs!",
            //    surfer1, break2);
            //comment3.CommentDateTime = new DateTime(2002, 01, 01);

            //Comment comment7 = new Comment("Hope you like surfing lefts!",
            //    surfer1, break3);
            //comment7.CommentDateTime = new DateTime(2006, 01, 01);


            //Load There Now data
            //Surfer surfer3 = new Surfer("Laird", "Hamilton", "USWC");
            //Surfer surfer4 = new Surfer("Andy", "Schultz", "USWC");
            //Surfer surfer5 = new Surfer("Brian", "Sonico", "USWC");
            //Surfer surfer6 = new Surfer("Owen", "West", "USWC");
            //Surfer surfer7 = new Surfer("Scott", "McKeon", "USWC");
            //Surfer surfer8 = new Surfer("Jake", "Green", "USWC");
            //Surfer surfer9 = new Surfer("Mats", "Malin", "USWC");
            //Surfer surfer10 = new Surfer("Jonas", "Blaisenborg", "USWC");
            //break1.ThereNow.Add(surfer1);
            //break1.ThereNow.Add(surfer2);
            //break2.ThereNow.Add(surfer3);
            //break2.ThereNow.Add(surfer4);
            //break2.ThereNow.Add(surfer5);
            //break2.ThereNow.Add(surfer6);
            //break2.ThereNow.Add(surfer7);
            //break2.ThereNow.Add(surfer8);
            //break2.ThereNow.Add(surfer9);
            //break3.ThereNow.Add(surfer10);
            #endregion 

            //Load Break Data
            //Use creds to retrieve breaks user is related to. 

            //Load Comment Data

            this.IsDataLoaded = true;
        }
    }
}
