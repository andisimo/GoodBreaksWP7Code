﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace GoodBreaks
{
    public class Session : ICommentable, INotifyPropertyChanged 
    {
        //fields
        private Guid _id;
        private List<Surfer> _surfersAtSession = new List<Surfer>();
        private ICollection<Comment> _comments = new List<Comment>(); 

        //properties
        public Guid Id
        {
            get { return _id; }
        }

        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        public Break SessionBreak { get; set; }

        public ICollection<Surfer> SurfersAtSession
        {
            get { return _surfersAtSession; }
            set { _surfersAtSession = value as List<Surfer>; }
        }

        public ICollection<Comment> Comments
        {
            get
            {
                return _comments;
            }
            set
            {
                if(_comments != value)
                {
                    _comments = value;
                    NotifyPropertyChanged("Comments");
                }
            }
        }

        //constructors
        public Session()
        {
            _id = Guid.NewGuid(); 
        }
        
        //methods
        public void AddSurfer(Surfer surferToAdd)
        {
            SurfersAtSession.Add(surferToAdd);
            surferToAdd.Sessions.Add(this);
        }

        public ICollection<Surfer> RemoveSurfer(Surfer surferToRemove)
        {
            SurfersAtSession.Remove(surferToRemove);
            surferToRemove.Sessions.Remove(this); 
            return SurfersAtSession;
        }

        public void AddComment(Comment comment)
        {
            throw new NotImplementedException();
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
