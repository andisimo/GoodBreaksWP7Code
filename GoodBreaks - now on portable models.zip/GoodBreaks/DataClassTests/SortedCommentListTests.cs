﻿using System;
using NUnit.Framework;
using GoodBreaks;

namespace DataClassTests
{
    [TestFixture]
    public class SortedCommentListTests
    {
        [Test]
        public void Sorting()
        {
            Comment comment2 = new Comment(text: "Second Comment", fromSurfer: new Surfer("First", "Last"), commentRegarding: new Surfer("First", "Last"));
            comment2.CommentDateTime = new DateTime(2011, 01, 01);

            Comment comment1 = new Comment(text: "First Comment", fromSurfer: new Surfer("First", "Last"), commentRegarding: new Surfer("First", "Last"));
            comment1.CommentDateTime = new DateTime(2012, 01, 01);

            Comment comment3 = new Comment(text: "Third Comment", fromSurfer: new Surfer("First", "Last"), commentRegarding: new Surfer("First", "Last"));
            comment3.CommentDateTime = new DateTime(2013, 01, 01);

            SortedCommentList commentList = new SortedCommentList();
            commentList.Add(comment2);
            commentList.Add(comment1);
            commentList.Add(comment3);

            //Assert.AreEqual(comment2, commentList.SortedComments[0]);

            Assert.AreEqual(1, 1);
        }
    }
}
