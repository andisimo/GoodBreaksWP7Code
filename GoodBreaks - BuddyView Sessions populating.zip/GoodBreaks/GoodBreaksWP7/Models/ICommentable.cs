﻿using System.Collections.Generic;

namespace GoodBreaksClasses
{
    public interface ICommentable
    {
        SortedCommentList CommentsAboutMe
        { get; set; }

        void AddComment(Comment comment);
    }
}
