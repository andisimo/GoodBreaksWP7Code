﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyListViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Surfer> _surfers = new ObservableCollection<Surfer>();
        public ObservableCollection<Surfer> Surfers
        {
            get { return _surfers; }
            set
            {
                if (_surfers != value)
                {
                    _surfers = value;
                    NotifyPropertyChanged("Surfers");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool IsDataLoaded { get; private set; }

        public void LoadData()
        {
            string _url = string.Format("http://staginggoodbreaks.cloudapp.net:8080/api/{0}?{1}={2}&{3}={4}",
                "buddies", "surferPK", "USWC", "surferRK", "sur-50d30e01-5a35-4194-9063-d501917fa5d5");
            var request = (HttpWebRequest)WebRequest.Create(_url);
            request.Method = "GET";
            request.BeginGetResponse(new AsyncCallback(ResponseCallback), request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            string responseString;
            var buddyList = new List<Surfer>();

            using (var response = (HttpWebResponse)request.EndGetResponse(result))
            {
                using (Stream streamResponse = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(streamResponse);
                    responseString = reader.ReadToEnd();
                    reader.Close();
                }
            }

            if (responseString != null)
            {
                buddyList = JsonConvert.DeserializeObject<List<Surfer>>(responseString);
            }

            UIThread.Invoke(() =>
            {
                foreach (Surfer s in buddyList)
                {
                    this.Surfers.Add(s);
                }
            });

            this.IsDataLoaded = true;
        }
    }
}
