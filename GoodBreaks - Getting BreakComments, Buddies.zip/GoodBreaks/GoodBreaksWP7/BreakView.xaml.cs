﻿using Microsoft.Phone.Controls;
using System.Windows.Navigation;

namespace GoodBreaksWP7
{
    public partial class BreaksView : PhoneApplicationPage
    {
        public BreaksView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string selectedIndex = "";
            if (NavigationContext.QueryString.TryGetValue("selectedItem", out selectedIndex))
            {
                int index = int.Parse(selectedIndex);
                DataContext = App.BreakListVm.Breaks[index];

                App.BreakListVm.GetCommentsForCurrent(index);
            }
        }
    }
}