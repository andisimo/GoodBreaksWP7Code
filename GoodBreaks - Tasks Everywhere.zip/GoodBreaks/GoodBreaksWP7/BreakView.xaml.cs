﻿using Microsoft.Phone.Controls;
using System.Windows.Navigation;

namespace GoodBreaksWP7
{
    public partial class BreaksView : PhoneApplicationPage
    {
        public BreaksView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string selectedIndex = "";
            if (NavigationContext.QueryString.TryGetValue("selectedItem", out selectedIndex))
            {
                int index = int.Parse(selectedIndex);
                //I used to declare a variable here and initialize it to the BreakVMs[index] item. 
                //However, this might be why INotifyPropertyChanged is not working - because I'm 
                //notifying on a different instance of the object than the one being bound to. So 
                //here, I'm setting the datacontext directly to the APp.BreaklistVM.BreakVMs[index] object. 
                DataContext = App.BreakListVm.BreakVMs[index];
                App.BreakListVm.BreakVMs[index].GetCollectionsForCurrent(index);
            }
        }
    }
}