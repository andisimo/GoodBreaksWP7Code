﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using GoodBreaksTypes;

namespace GoodBreaksWP7.Utilities
{
    public static class ConnectionHelper
    {
        private static string baseUrl = "http://goodbreaks.cloudapp.net/api/";

        //methods
        public static HttpWebRequest GET(string endpointName, Dictionary<string, string> arguments = null)
        {
            string _url = baseUrl + endpointName;

            if (arguments != null)
            {
                _url = _url + "?";
                foreach (KeyValuePair<string, string> arg in arguments)
                {
                    if ((_url[_url.Length - 1]).ToString() != "?")
                        _url = _url + "&";

                    _url = _url + arg.Key + "=" + arg.Value;
                }
            }

            var request = (HttpWebRequest)WebRequest.Create(_url);
            request.Method = "GET";

            request.Headers["Authorization"] = "Basic " + App.UserVm.LoginCredentials.base64Realm;

            return request;
        }

        public static HttpWebRequest POST(Surfer surfer, Dictionary<string, string> arguments, 
            string username =  null, string password = null)
        {
            var request = (HttpWebRequest)WebRequest.Create(baseUrl);
            request.Method = "POST";
            request.ContentType = "text/json; charset=utf-8";
            request.Headers["Authorization"] = "Basic "; // + hashed, 64 password.
            //request.Credentials = new NetworkCredential(username, password); 

            return request;
        }

    }
}
