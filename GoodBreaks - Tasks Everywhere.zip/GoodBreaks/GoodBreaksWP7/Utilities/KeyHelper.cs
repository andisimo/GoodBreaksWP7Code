﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace GoodBreaksWP7.Utilities
{
    public static class KeyHelper
    {
        public static Dictionary<string, string> ParseCompleteKey(string completeKey)
        {
            //example:
            //USWC|bre-28197a6a-f12d-4fdb-a87d-4abaa731437f
            //names of values returned: "type", "id", "region"

            var returnPairs = new Dictionary<string, string>();

            try
            {
                int bar = completeKey.IndexOf("|");
                int guidStart = completeKey.IndexOf("-") + 1;


                var region = completeKey.Substring(0, bar);
                returnPairs.Add("region", region);

                var type = completeKey.Substring(bar + 1, (guidStart - 1) - (bar + 1));
                switch (type)
                {
                    case "sur":
                        type = "Surfer";
                        break;
                    case "ses":
                        type = "Session";
                        break;
                    case "bre":
                        type = "Break";
                        break;
                    case "com":
                        type = "Comment";
                        break;
                    case "boa":
                        type = "SurfBoard";
                        break;
                }
                returnPairs.Add("type", type);

                var id = completeKey.Substring(bar + 1);
                returnPairs.Add("id", id);
            }
            catch
            {
                throw new FormatException(@"The completeKey passed must be in the format: 
                    [Region]|[row prefix]-[id string]. Example: USWC|sur-123-abc-333q4");
            }

            return returnPairs;
        }

        public static string ConstructCompleteKey(string partitionKey, string rowKey)
        {
            if (partitionKey != null && partitionKey != "" && rowKey != null && rowKey != "")
            {
                string completeKey = partitionKey + "|" + rowKey;
                return completeKey;
            }
            else
            {
                throw new ArgumentNullException("partitionKey or rowKey",
                   "The partitionKey or rowKey argument was" +
                   "NULL or blank for the TableStorageHelper.ConstructCompleteKey method." +
                   "NULL or blank values are not permitted.");
            }
        }
    }
}
