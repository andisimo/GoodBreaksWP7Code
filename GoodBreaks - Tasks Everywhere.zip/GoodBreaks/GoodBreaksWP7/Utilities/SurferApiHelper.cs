﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace GoodBreaksWP7.Utilities
{
    internal static class SurferApiHelper
    {
        //methods
        public static HttpWebRequest GetOneSurfer(string surferCompleteKey)
        {
            var surferKeys = KeyHelper.ParseCompleteKey(surferCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("surferPK", surferKeys["region"]);
            args.Add("surferRK", surferKeys["id"]);

            var request = ConnectionHelper.GET("surfers", args); 
            return request;
        }

        internal static HttpWebRequest GetBuddiesForSurfer(string surferCompleteKey)
        {
            var surferKeys = KeyHelper.ParseCompleteKey(surferCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("surferPK", surferKeys["region"]);
            args.Add("surferRK", surferKeys["id"]);

            var request = ConnectionHelper.GET("collectionofbuddies", args);
            return request;
        }

        internal static HttpWebRequest GetSurfersThereNow(string relatedObjectCompleteKey)
        {
            var args = new Dictionary<string, string>();
            args.Add("relatedObjectCompleteKey", relatedObjectCompleteKey);

            var request = ConnectionHelper.GET("collectionofsurfers", args);
            return request;
        }
    }
}
