﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyViewModel
    {
        //private fields
        private Surfer _thisSurfer;
        private ObservableCollection<Comment> _allComments = new ObservableCollection<Comment>();
        private ObservableCollection<Session> _sessions = new ObservableCollection<Session>();

        //public properties
        public Surfer ThisSurfer
        {
            get
            {
                return _thisSurfer;
            }
            set
            {
                if (_thisSurfer != value)
                {
                    _thisSurfer = value;
                    NotifyPropertyChanged("ThisSurfer");
                }
            }
        }

        public ObservableCollection<Comment> AllComments
        {
            get
            {
                List<Comment> comments = new List<Comment>();
                comments.AddRange(_allComments);

                comments.Sort( (comment1, comment2) 
                    => comment1.Timestamp.CompareTo(comment2.Timestamp));

                _allComments.Clear();
                foreach (Comment c in comments)
                {
                    _allComments.Add(c);
                }
                
                return _allComments;
            }
            set
            {
                if (value != _allComments)
                {
                    NotifyPropertyChanged("AllComments");
                    _allComments = value;
                }
            }
        }

        public ObservableCollection<Session> Sessions
        {
            get
            {
                return _sessions; 
            }
            set
            {
                if (value != _sessions)
                {
                    NotifyPropertyChanged("Sessions");
                    _sessions = value; 
                }
            }
        }

        //constructor
        public BuddyViewModel(Surfer surfer)
        {
            ThisSurfer = surfer;
        }

        //methods
        public void GetCollectionsForCurrent()
        {
            ThisSurfer.Sessions.Clear();
            ThisSurfer.CommentsAboutMe.Comments.Clear();
            ThisSurfer.CommentsByMe.Comments.Clear();
            AllComments.Clear();
            Sessions.Clear();

            GetSessionsForCurrent();
            GetCommentsAboutForCurrent();
            GetCommentsByForCurrent();
        }

        public void GetSessionsForCurrent()
        {
            var request = SessionApiHelper.GetSessionsForSurfer(KeyHelper.ConstructCompleteKey
                (ThisSurfer.PartitionKey, ThisSurfer.RowKey));

            var getSessionsTask = Task.Factory.StartNew(() =>
                {
                    var sessions = TaskHelper<Session>.RetrieveCollectionTask(request);
                    return sessions;
                }
            );

            getSessionsTask.ContinueWith((antecedent) =>
                {
                    if(antecedent.IsFaulted)
                    { return; }

                    var sessionList = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                    {
                        foreach (Session s in sessionList)
                        {
                            ThisSurfer.Sessions.Add(s);
                            Sessions.Add(s); 
                        }
                    });
                });
        }

        private void GetCommentsAboutForCurrent()
        {
            var request = CommentApiHelper.GetCommentsAboutMe(KeyHelper.ConstructCompleteKey(
                ThisSurfer.PartitionKey, ThisSurfer.RowKey));

            var getCommentsAboutTask = Task.Factory.StartNew(() =>
                {
                    var comments = TaskHelper<Comment>.RetrieveCollectionTask(request);
                    return comments;
                });

            getCommentsAboutTask.ContinueWith((antecedent) =>
                {
                    if (antecedent.IsFaulted)
                    { return; }

                    var commentList = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                    {
                        foreach (Comment c in commentList)
                        {
                            AllComments.Add(c);
                            GetCommentRelatedInfo(c);
                        }
                    });
                });
        }

        private void GetCommentsByForCurrent()
        {
            var request = CommentApiHelper.GetCommentsByMe(KeyHelper.ConstructCompleteKey(
                ThisSurfer.PartitionKey, ThisSurfer.RowKey));

            var getCommentsTask = Task.Factory.StartNew(() =>
                {
                    var comments = TaskHelper<Comment>.RetrieveCollectionTask(request);
                    return comments;
                });

            getCommentsTask.ContinueWith((antecedent) =>
                {
                    var commentList = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                    {
                        foreach (Comment c in commentList)
                        {
                            AllComments.Add(c);
                            GetCommentRelatedInfo(c);
                        }
                    });
                });
        }

        private void GetCommentRelatedInfo(Comment c)
        {
            var fromSurferRequest = SurferApiHelper.GetOneSurfer(c.FromSurferKey);

            var getSurferTask = Task.Factory.StartNew(() =>
                { 
                    var surfer = TaskHelper<Surfer>.RetrieveItemTask(fromSurferRequest);
                    return surfer;
                });

            getSurferTask.ContinueWith((antecedent) =>
                {
                    if (antecedent.IsFaulted)
                    {
                        return;
                    }

                    var surfer = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                        {
                            c.FromSurfer = surfer;
                            AllComments.Remove(c);
                            AllComments.Add(c);
                        });
                });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
