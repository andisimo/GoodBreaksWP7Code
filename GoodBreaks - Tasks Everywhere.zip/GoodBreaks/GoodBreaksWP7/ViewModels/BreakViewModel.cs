﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GoodBreaksTypes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using GoodBreaksWP7.Utilities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace GoodBreaksWP7.ViewModels
{
    public class BreakViewModel
    {
        //private fields
        private Break _thisBreak;
        private ObservableCollection<Comment> _comments = new ObservableCollection<Comment>();
        private ObservableCollection<Surfer> _surfers = new ObservableCollection<Surfer>(); 

        //public properties
        public Break ThisBreak
        {
            get
            {
                return _thisBreak;
            }
            set
            {
                if (_thisBreak != value)
                {
                    _thisBreak = value;
                    NotifyPropertyChanged("ThisBreak");
                }
            }
        }

        public ObservableCollection<Comment> Comments
        {
            get
            {
                List<Comment> comments = new List<Comment>();
                comments.AddRange(_comments);

                comments.Sort((comment1, comment2)
                    => comment1.Timestamp.CompareTo(comment2.Timestamp));

                _comments.Clear();
                foreach (Comment c in comments)
                {
                    _comments.Add(c);
                }

                return _comments;
            }
            set
            {
                if(_comments != value)
                {
                    _comments = value;
                    NotifyPropertyChanged("Comments");
                }
            }
        }

        public ObservableCollection<Surfer> Surfers
        {
            get
            {
                return _surfers;
            }
            set
            {
                if (_surfers != value)
                {
                    _surfers = value;
                    NotifyPropertyChanged("Surfers"); 
                }
            }
        }

        //constructor
        public BreakViewModel(Break break1)
        {
            ThisBreak = break1;
        }

        //methods
        public void GetCollectionsForCurrent(int index)
        {
            ThisBreak.CommentsAboutMe.Comments.Clear();
            ThisBreak.ThereNow.Clear();

            GetCommentsAboutForCurrent();
            GetSurfersAtCurrent();
        }

        private void GetCommentsAboutForCurrent()
        {
            var request = CommentApiHelper.GetCommentsAboutMe(KeyHelper.ConstructCompleteKey(
                ThisBreak.PartitionKey, ThisBreak.RowKey));

            var getCommentsAboutTask = Task.Factory.StartNew(() =>
                {
                    var comments = TaskHelper<Comment>.RetrieveCollectionTask(request);
                    return comments;
                });

            getCommentsAboutTask.ContinueWith((antecedent) =>
                {
                    if (antecedent.IsFaulted)
                    { return; }

                    var commentList = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                    {
                        foreach (Comment c in commentList)
                        {
                            ThisBreak.CommentsAboutMe.Comments.Add(c); 
                            Comments.Add(c);
                            GetCommentRelatedInfo(c);
                        }
                    });
                });
        }

        private void GetSurfersAtCurrent()
        {
            var thereNowRequest = SurferApiHelper.GetSurfersThereNow(KeyHelper.ConstructCompleteKey(
                ThisBreak.PartitionKey, ThisBreak.RowKey));

            var getSurfersTask = Task.Factory.StartNew(() =>
                {
                    var surfers = TaskHelper<Surfer>.RetrieveCollectionTask(thereNowRequest);
                    return surfers;
                });

            getSurfersTask.ContinueWith((antecedent) =>
                {
                    if (antecedent.IsFaulted)
                    { return; }

                    var surferList = antecedent.Result.Result;
                    int i = 3; 
                    UIThread.Invoke(() =>
                    {
                        foreach (Surfer s in surferList)
                        {
                            ThisBreak.ThereNow.Add(s); 
                            Surfers.Add(s); 
                        }
                    });
                });
        }

        private void GetCommentRelatedInfo(Comment c)
        {
            var fromSurferRequest = SurferApiHelper.GetOneSurfer(c.FromSurferKey);

            var getSurferTask = Task.Factory.StartNew(() =>
            {
                var surfer = TaskHelper<Surfer>.RetrieveItemTask(fromSurferRequest);
                return surfer;
            });

            getSurferTask.ContinueWith((antecedent) =>
            {
                if (antecedent.IsFaulted)
                {
                    return;
                }

                var surfer = antecedent.Result.Result;
                UIThread.Invoke(() =>
                {
                    c.FromSurfer = surfer;
                    Comments.Remove(c);
                    Comments.Add(c);
                });
            });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        
    }
}
