﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;

namespace GoodBreaksWP7.ViewModels
{
    public class BreakListViewModel : INotifyPropertyChanged
    {
        //private fields
        private ObservableCollection<BreakViewModel> _breakVMs = new ObservableCollection<BreakViewModel>();
        
        //public properties
        public ObservableCollection<BreakViewModel> BreakVMs
        {
            get { return _breakVMs; }
            set
            {
                if (_breakVMs != value)
                {
                    _breakVMs = value;
                    NotifyPropertyChanged("BreakVMs"); 
                }
            }
        }

        public bool IsDataLoaded { get; private set; }

        //methods
        public void LoadData()
        {
            var breaksRequest = BreakApiHelper.GetBreaksForSurfer(KeyHelper.ConstructCompleteKey
                (App.UserVm.LoggedInSurfer.PartitionKey, App.UserVm.LoggedInSurfer.RowKey));

            var breaksTask = Task.Factory.StartNew(() =>
                {
                    var breaks = TaskHelper<Break>.RetrieveCollectionTask(breaksRequest);
                    return breaks; 
                });
            
            breaksTask.ContinueWith((antecedent) =>
                {
                    if (antecedent.IsFaulted)
                    { return; }

                    var breakList = antecedent.Result.Result;
                    UIThread.Invoke(() =>
                    {
                        foreach (Break b in breakList)
                        {
                            this.BreakVMs.Add(new BreakViewModel(b));
                        }
                    });

                    this.IsDataLoaded = true;
                });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
