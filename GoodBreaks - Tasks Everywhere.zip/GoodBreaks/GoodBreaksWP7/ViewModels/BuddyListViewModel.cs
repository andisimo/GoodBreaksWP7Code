﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyListViewModel : INotifyPropertyChanged
    {
        //private fields
        private ObservableCollection<BuddyViewModel> _buddyVMs = new ObservableCollection<BuddyViewModel>();

        //public properties
        public ObservableCollection<BuddyViewModel> BuddyVMs
        {
            get { return _buddyVMs; }
            set
            {
                if (_buddyVMs != value)
                {
                    _buddyVMs = value;
                    NotifyPropertyChanged("BuddyVMs");
                }
            }
        }

        public bool IsDataLoaded { get; private set; }

        //methods
        public void LoadData()
        {
            var buddiesRequest = SurferApiHelper.GetBuddiesForSurfer(KeyHelper.ConstructCompleteKey
                (App.UserVm.LoggedInSurfer.PartitionKey, App.UserVm.LoggedInSurfer.RowKey));

            var getBuddiesTask = Task.Factory.StartNew(() =>
                {
                    var buddiesTask = TaskHelper<Surfer>.RetrieveCollectionTask(buddiesRequest);
                    return buddiesTask;
                });

            getBuddiesTask.ContinueWith((antecedent) =>
            {
                if (antecedent.IsFaulted)
                { return; }

                var surferList = antecedent.Result.Result;
                UIThread.Invoke(() =>
                {
                    foreach (Surfer s in surferList)
                    {
                        this.BuddyVMs.Add(new BuddyViewModel(s));
                    }
                });

                this.IsDataLoaded = true;
            });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
