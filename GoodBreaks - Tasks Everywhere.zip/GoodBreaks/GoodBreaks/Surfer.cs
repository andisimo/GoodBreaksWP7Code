﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GoodBreaks
{
    public class Surfer : ICommentable
    {
        //fields
        private Guid _id;
        private string _imageLocation;
        private List<SurfBoard> _surfBoards = new List<SurfBoard>();
        private List<Session> _sessions = new List<Session>();
        private ICollection<Comment> _comments = new ObservableCollection<Comment>();

        //properties
        public Guid Id
        {
            get { return _id; }
        }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string NickName { get; set; }

        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

        public string Description { get; set; }

        public string ImageLocation
        {
            get { return _imageLocation; }
            set { _imageLocation = value; }
        }

        public ICollection<SurfBoard> SurfBoards
        {
            get { return _surfBoards; }
            set { _surfBoards = value as List<SurfBoard>; }
        }

        public ICollection<Session> Sessions
        {
            get { return _sessions; }
            set { _sessions = value as List<Session>; }
        }

        public ICollection<Comment> Comments
        {
            get { return _comments; }
            set { _comments = value; }
        }

        //constructors
        public Surfer(string surferFirstName, string surferLastName)
        {
            _id = Guid.NewGuid();
            FirstName = surferFirstName;
            LastName = surferLastName;
        }

        public Surfer(string surferFirstName, string surferLastName, 
            ICollection<SurfBoard> surferBoards)
        {
            _id = Guid.NewGuid();
            FirstName = surferFirstName;
            LastName = surferLastName;
            SurfBoards = surferBoards; 
        }

        //methods
        public void AddBoard(SurfBoard board)
        {
            SurfBoards.Add(board);
        }

        public void RemoveBoard(SurfBoard board)
        {
            SurfBoards.Remove(board); 
        }

        public void JoinSession(Session sessionToJoin)
        {
            Sessions.Add(sessionToJoin);
            sessionToJoin.AddSurfer(this); 
        }

        public void UndoJoindSession(Session sessionToUndoJoin)
        {
            Sessions.Remove(sessionToUndoJoin);
            sessionToUndoJoin.RemoveSurfer(this); 
        }

        public void AddComment(Comment comment)
        {
            Comments.Add(comment);
        }
    }
}
