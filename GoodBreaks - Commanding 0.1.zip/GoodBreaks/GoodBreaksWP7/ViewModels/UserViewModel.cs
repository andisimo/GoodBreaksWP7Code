﻿using System.IO;
using System.Net;
using System.Windows.Input;
using GoodBreaksClasses;
using GalaSoft.MvvmLight.Command;
using System;
using Newtonsoft.Json;
using System.Text;

namespace GoodBreaksWP7.ViewModels
{
    public class UserViewModel
    {
        //internal properties
        internal static Surfer LoggedInSurfer { get; set; }
        internal string UserName { get; set; }
        internal string Password { get; set; }

        //public propertis
        public ICommand CreateUserCommand { get; set; }

        //constructors
        public UserViewModel()
        {
            CreateUserCommand = new RelayCommand(CreateUserSurfer);
        }

        //methods
        public void CreateUserSurfer()
        {
            HttpWebRequest request = HttpWebRequest.Create("http://127.0.0.2:8080/api/surfers/") as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "text/json";
            request.BeginGetRequestStream(new AsyncCallback(RequestCallback), request);

        }

        private static void RequestCallback(IAsyncResult result)
        {
            HttpWebRequest request = result.AsyncState as HttpWebRequest;

            Stream postStream = request.EndGetRequestStream(result); 

            Surfer surfer = new Surfer("Windows", "Phone", "USWC");

            Formatting formatting = new Formatting();
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            string json = JsonConvert.SerializeObject(surfer, formatting, settings);

            byte[] byteArray = Encoding.UTF8.GetBytes(json);

            postStream.Write(byteArray, 0, json.Length);
            postStream.Close();

            request.BeginGetResponse(new AsyncCallback(ResponseCallback), request);
        }

        private static void ResponseCallback(IAsyncResult result)
        {
            HttpWebRequest request = result.AsyncState as HttpWebRequest;
            HttpWebResponse response = request.EndGetResponse(result) as HttpWebResponse;
            Stream streamResponse = response.GetResponseStream();
            StreamReader reader = new StreamReader(streamResponse);
            string responseString = reader.ReadToEnd();
            streamResponse.Close();
            reader.Close();
            response.Close();
        }
    }
}
