﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using GoodBreaksWP7.ViewModels;

namespace GoodBreaksWP7
{
    public partial class CreateUser : PhoneApplicationPage
    {
        public CreateUser()
        {
            InitializeComponent();
        }

        private void thisPage_Loaded(object sender, RoutedEventArgs e)
        {
            App.UserVm = new UserViewModel();

            var page = sender as PhoneApplicationPage;
            page.DataContext = App.UserVm;
        }
    }
}