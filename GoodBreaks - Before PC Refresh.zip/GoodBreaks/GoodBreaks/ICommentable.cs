﻿using System.Collections.Generic;

namespace GoodBreaks
{
    public interface ICommentable
    {
        ICollection<Comment> Comments
        { get; set; }

        void AddComment(Comment comment);
    }
}
