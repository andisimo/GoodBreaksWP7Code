﻿using System.IO;
using System.Net;
using System.Windows.Input;
using GoodBreaksTypes;
using GalaSoft.MvvmLight.Command;
using System;
using Newtonsoft.Json;
using System.Text;
using GoodBreaksWP7.Utilities;

namespace GoodBreaksWP7.ViewModels
{
    public class UserViewModel
    {
        //internal properties
        internal Surfer LoggedInSurfer { get; set; }
        internal string UserName { get; set; }
        internal string Password { get; set; }
        internal string Salt { get; set; }
        internal Credentials LoginCredentials { get; set; }

        //public propertis
        public ICommand CreateUserCommand { get; set; }

        //constructors
        public UserViewModel()
        {
            //CreateUserCommand = new RelayCommand(CreateUserSurfer);
        }

        //methods
        public void CreateUserSurfer()
        {
            var request = (HttpWebRequest)WebRequest.Create("http://staginggoodbreaks.cloudapp.net:8080/api/surfers/");
            request.Method = "POST";
            request.ContentType = "text/json; charset=utf-8";
            request.BeginGetRequestStream(new AsyncCallback(RequestCallback), request);
        }

        private static void RequestCallback(IAsyncResult result)
        {
            HttpWebRequest request = (HttpWebRequest)result.AsyncState;

            using (Stream postStream = request.EndGetRequestStream(result))
            {
                Surfer surfer = new Surfer("Windows", "Phone", "USCA");

                Formatting formatting = new Formatting();
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                string json = JsonConvert.SerializeObject(surfer, formatting, settings);

                byte[] byteArray = Encoding.UTF8.GetBytes(json);

                postStream.Write(byteArray, 0, json.Length);
            }

            request.BeginGetResponse(ResponseCallback, request);
        }

        private static void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            using (var response = (HttpWebResponse)request.EndGetResponse(result))
            {

                using (Stream streamResponse = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(streamResponse);
                    string responseString = reader.ReadToEnd();
                    reader.Close();
                }
            }
        }
    }
}
