﻿using System.Windows.Navigation;
using Microsoft.Phone.Controls;

namespace GoodBreaksWP7
{
    public partial class BuddyView : PhoneApplicationPage
    {
        public BuddyView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string selectedIndex = "";
            if (NavigationContext.QueryString.TryGetValue("selectedItem", out selectedIndex))
            {
                int index = int.Parse(selectedIndex);
                var buddyVM = App.BuddyListVm.BuddyVMs[index];
                DataContext = buddyVM;

                buddyVM.GetCollectionsForCurrent();
            }
        }
    }
}