﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace GoodBreaksWP7.Utilities
{
    internal static class BreakApiHelper
    {
        //methods
        public static HttpWebRequest GetOneBreak(string breakCompleteKey)
        {
            var breakKeys = KeyHelper.ParseCompleteKey(breakCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("breakPK", breakKeys["region"]);
            args.Add("breakRK", breakKeys["id"]);

            var request = ConnectionHelper.GET("breaks", args); 
            return request;
        }

        internal static HttpWebRequest GetBreaksForSurfer(string surferCompleteKey)
        {
            var surferKeys = KeyHelper.ParseCompleteKey(surferCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("relatedObjectPK", surferKeys["region"]);
            args.Add("relatedObjectRK", surferKeys["id"]);

            var request = ConnectionHelper.GET("collectionofbreaks", args);
            return request;
        }
    }
}
