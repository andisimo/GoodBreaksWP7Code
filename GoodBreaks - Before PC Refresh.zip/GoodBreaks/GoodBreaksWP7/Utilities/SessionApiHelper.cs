﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace GoodBreaksWP7.Utilities
{
    internal static class SessionApiHelper
    {
        //methods
        internal static HttpWebRequest GetOneSession(string sessionCompleteKey)
        {
            var commentKeys = KeyHelper.ParseCompleteKey(sessionCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("sessionPK", commentKeys["region"]);
            args.Add("sessionRK", commentKeys["id"]);

            var request = ConnectionHelper.GET("sessions", args);
            return request;
        }

        internal static HttpWebRequest GetSessionsForSurfer(string surferCompleteKey)
        {
            var surferKeys = KeyHelper.ParseCompleteKey(surferCompleteKey);
            var args = new Dictionary<string, string>();
            args.Add("relatedObjectPK", surferKeys["region"]);
            args.Add("relatedObjectRK", surferKeys["id"]);

            var request = ConnectionHelper.GET("collectionofsessions", args);
            return request;  
        }
    }
}
