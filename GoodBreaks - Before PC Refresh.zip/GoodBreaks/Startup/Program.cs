﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GoodBreaksWP7.Models;

namespace Startup
{
    class Program
    {
        static void Main(string[] args)
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            SurfBoard board1 = new SurfBoard(name: "name0");
            testSurferNoboards.AddBoard(board1);
            testSurferNoboards.AddBoard(new SurfBoard(name: "name1"));
            testSurferNoboards.RemoveBoard(board1);

            int i = board1.GetHashCode(); 
            board1.Equals(new SurfBoard(name: "name0")); 
        }
    }
}
