﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using GoodBreaks;

namespace DataClassTests
{
    [TestFixture]
    class SurferTests
    {       
        [Test]
        public void Constructor3Params()
        {
            Surfer testSurfer = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            Assert.AreEqual(new string[] {"Andy", "Schultz", "Endless Paddler"}, 
                new string[] {testSurfer.FirstName, testSurfer.LastName}); 
        }

        [Test]
        public void Constructor4ParamsListBoardCount()
        {
            List<SurfBoard> boards = new List<SurfBoard>(); 
            boards.Add(new SurfBoard("name1"));
            boards.Add(new SurfBoard("name2")); 

            Surfer testSurfer = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz", 
                surferBoards: boards);
            Assert.AreEqual(2, testSurfer.SurfBoards.Count); 
        }

        [Test]
        public void Constructor4ParamsListBoardValues()
        {
            List<SurfBoard> boards = new List<SurfBoard>();
            boards.Add(new SurfBoard("name1"));
            boards.Add(new SurfBoard("name2"));

            Surfer testSurfer = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz",
                surferBoards: boards);
            List<SurfBoard> boardList = testSurfer.SurfBoards as List<SurfBoard>;
            Assert.IsNotNull(boardList[0].BoardName);
            Assert.IsNotNull(boardList[1].BoardName);
        }

        [Test]
        public void AddBoard()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            testSurferNoboards.AddBoard(new SurfBoard(name: "name0"));

            List<SurfBoard> boardList = testSurferNoboards.SurfBoards as List<SurfBoard>;
            Assert.AreEqual(boardList[0].BoardName, "name0"); 
        }

        [Test]
        public void AddBoardTwice()
        {
            //Cannot refactor to put this instantiation outside of the methods.
            //If you do, the count tests will not work, because each test method's
            //surfBoards will be added to the surfer's surfBoards collection. 
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            testSurferNoboards.AddBoard(new SurfBoard(name: "name0"));
            testSurferNoboards.AddBoard(new SurfBoard(name: "name1"));
            List<SurfBoard> boardList = testSurferNoboards.SurfBoards as List<SurfBoard>;
            Assert.AreEqual(2, boardList.Count); 
        }

        [Test]
        public void RemoveBoard()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");

            SurfBoard board1 = new SurfBoard(name: "name0");
            SurfBoard board2 = new SurfBoard(name: "name1"); 

            testSurferNoboards.AddBoard(board1);
            testSurferNoboards.AddBoard(board2);

            testSurferNoboards.RemoveBoard(board1);

            List<SurfBoard> boardList = testSurferNoboards.SurfBoards as List<SurfBoard>;
            Assert.AreEqual(1, boardList.Count);
            Assert.AreEqual("name1", boardList[0].BoardName);
        }

        [Test]
        public void JoinSessionAddsCorrectSessionReferenceToSurfer()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            Session testSession = new Session();
            testSurferNoboards.JoinSession(testSession);
            var sessions = testSurferNoboards.Sessions as List<Session>;
            Assert.AreEqual(testSession, sessions[0]); 
        }

        [Test]
        public void JoinSessionAddsCorrectSurferReferenceToSession()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            Session testSession = new Session();
            testSurferNoboards.JoinSession(testSession);
            var surfers = testSession.SurfersAtSession as List<Surfer>;
            Assert.AreEqual(testSurferNoboards, surfers[0]);
        }

        [Test]
        public void UndoJoinSessionRemovesCorrectSessionReferenceFromSurfer()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            Session testSession = new Session();
            testSurferNoboards.JoinSession(testSession);
            testSurferNoboards.UndoJoindSession(testSession); 
            var sessions = testSurferNoboards.Sessions as List<Session>;
            Assert.False(sessions.Contains(testSession)); 
        }

        [Test]
        public void UndoJoinSessionRemovesCorrectSurferReferenceFromSession()
        {
            Surfer testSurferNoboards = new Surfer(surferFirstName: "Andy", surferLastName: "Schultz");
            Session testSession = new Session();
            testSurferNoboards.JoinSession(testSession);
            testSurferNoboards.UndoJoindSession(testSession); 
            var surfers = testSession.SurfersAtSession as List<Surfer>;
            Assert.False(surfers.Contains(testSurferNoboards)); 
        }
    }
}
