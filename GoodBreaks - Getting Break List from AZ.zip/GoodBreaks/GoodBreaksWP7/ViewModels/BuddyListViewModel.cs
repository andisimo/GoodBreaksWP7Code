﻿using System;
using System.ComponentModel;
using System.Collections.ObjectModel;
using GoodBreaksTypes;

namespace GoodBreaksWP7.ViewModels
{
    public class BuddyListViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Surfer> _surfers = new ObservableCollection<Surfer>();
        public ObservableCollection<Surfer> Surfers
        {
            get { return _surfers; }
            set
            {
                if (_surfers != value)
                {
                    _surfers = value;
                    NotifyPropertyChanged("Surfers");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool IsDataLoaded { get; private set; }

        public void LoadData()
        {
            var surfer1 = new Surfer("Kelly", "Slater", "USWC");
            surfer1.ImageLocation = "imageslater.jpg";
            surfer1.Description = "Just the most accomplished surfer ever. World champion more times than" +
                                  " I can count, dominating the sport for decades. alaskdfiaj aoid faoim aeio feioaweifin ajifeoaeofjaoewijf jaoiewjf awofij oawiejfawoifj ifeoai feojfeaofi j fejiaewofijae fejaifoewjfwaoefi feo fawoeifj awoefi jawoefjawo" +
                                  "a ;oweifj awoifj awoefi jawoefijawoeifja wofijaw ojwe oawj fwoajf woeijf aowijf oawij f" +
                                  "a woeif jawoi fjawofij awof ijaweofi jawoeifj aowifjewofjewofijawofjaewofij o" +
                                  "a;ewoifj aoiwejfaowifjioewfjwehf239qrh932hqfnvklvir9q 0q[09jfiqwviniq0gj 4[q0jfq0f";
            Surfers.Add(surfer1);

            var surfer2 = new Surfer("Noah", "Snyder", "USEC");
            surfer2.ImageLocation = "imagesnyder.jpg";
            surfer2.Description = "Christian surfer who found God in the waves.";
            Surfers.Add(surfer2);

            var surfer3 = new Surfer("Bethany", "Hamilton", "USWC");
            
            Surfers.Add(surfer3);
            surfer3.ImageLocation = "imagehamilton.jpg";
            surfer3.Description = "Champion surfer who did it with one arm. Lost my arm in a shark attack" +
                                  " when I was a teenager, came back and continued with a championship pro career.";

            var comment1 = new Comment("You are a true competitor Bethany. I didn't even think a person could surf with only one arm - I never would have thought a person could win championships with only one arm.", surfer1, surfer3);
            var comment2 =
                new Comment(
                    "Unbelievable the way you've come from an adverse situation and made it look so easy, Bethany. " +
                    "You are truly an inspiration to all of us. I am rooting for you every time simply because you " +
                    "stand for something more than other surfers.", surfer2, surfer3);

            this.IsDataLoaded = true;
        }
    }
}
