﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GoodBreaks;
using NUnit.Framework;

namespace DataClassTests
{
    [TestFixture]
    class SurferSessionLinkTests
    {
        [Test]
        public void Constructor()
        {

        }
    }
}
