﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoodBreaksClasses
{
    public static class KeyBuilder
    {
        //methods
        internal static string BuildAboutKey(Comment comment, string aboutTypeName)
        {
            string aboutKey = "";

            switch (aboutTypeName)
            {
                case "Surfer":
                    Surfer AboutSurfer = comment.About as Surfer;
                    aboutKey = AboutSurfer.PartitionKey + "|" + AboutSurfer.RowKey;
                    break;

                case "Break":
                    Break AboutBreak = comment.About as Break;
                    aboutKey = AboutBreak.PartitionKey + "|" + AboutBreak.RowKey;
                    break;

                case "Session":
                    Session AboutSession = comment.About as Session;
                    aboutKey = AboutSession.PartitionKey + "|" + AboutSession.RowKey;
                    break;
            }

            if (aboutKey != "")
            {
                return aboutKey;
            }
            else
            {
                throw new Exception("The comment's AboutKey could not be found.");
            }
        }

        internal static string BuildAboutKey(Comment comment, ICommentable aboutObject)
        {
            string aboutKey = "";

            Type type = aboutObject.GetType();
            string aboutTypeName = type.Name;

            switch (aboutTypeName)
            {
                case "Surfer":
                    Surfer AboutSurfer = comment.About as Surfer;
                    aboutKey = AboutSurfer.PartitionKey + "|" + AboutSurfer.RowKey;
                    break;

                case "Break":
                    Break AboutBreak = comment.About as Break;
                    aboutKey = AboutBreak.PartitionKey + "|" + AboutBreak.RowKey;
                    break;

                case "Session":
                    Session AboutSession = comment.About as Session;
                    aboutKey = AboutSession.PartitionKey + "|" + AboutSession.RowKey;
                    break;
            }

            if (aboutKey != "")
            {
                return aboutKey;
            }
            else
            {
                throw new Exception("The comment's AboutKey could not be found.");
            }
        }

        internal static string BuildFromKey(Surfer surfer)
        {
            return surfer.PartitionKey + "|" + surfer.RowKey;
        }
    }
}
