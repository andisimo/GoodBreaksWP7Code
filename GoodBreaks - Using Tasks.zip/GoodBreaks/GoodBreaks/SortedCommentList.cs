﻿using System.Collections.Generic;

namespace GoodBreaks
{
    public class SortedCommentList 
    {
        //fields
        private List<Comment> _sortedComments = new List<Comment>(); 

        //properties
        public List<Comment> SortedComments
        {
            get
            {
                _sortedComments.Sort(
                    (comment1, comment2) => comment1.CommentDateTime.CompareTo(comment2.CommentDateTime));

                return _sortedComments;
            } 
            
            set { _sortedComments = value; }
        }

        //constructors
        public SortedCommentList()
        {
                
        }

        public SortedCommentList(ICollection<Comment> comments)
        {
            _sortedComments = comments as List<Comment>;
        }

        //methods
        public void Add(Comment comment)
        {
            _sortedComments.Add(comment);
        }
    }
}
