﻿using System;
using System.Globalization;

namespace GoodBreaks
{
    public class Comment
    {
        //fields
        private Guid _id;

        //properties
        public Guid Id
        {
            get { return _id; }
        }

        public string CommentText { get; set; }

        public Surfer CommentingSurfer { get; set; }

        public ICommentable Regarding { get; set; }

        public DateTime CommentDateTime { get; set; }

        //public string CommentDateTimeString { 
        //    get
        //    {
        //        string returnString;
        //        var elapsedTime = DateTime.UtcNow - CommentDateTime;
                
        //        if(elapsedTime.Days > 365)
        //        {
        //            returnString = "Over a year ago.";
        //        }
        //        else if(elapsedTime.Days > 30)
        //        {
        //            var months = elapsedTime.Days / 30.0;
        //            var totalTimeString = months.ToString(CultureInfo.InvariantCulture);
        //            var monthsString = totalTimeString.Substring(0, totalTimeString.IndexOf(".", System.StringComparison.Ordinal));
        //            var monthsFraction = months%1; 
        //            returnString = "About " ;
        //        }

        //        return elapsedTime.Duration().ToString();
        //    }
        //}

        //constructors
        public Comment(string text, Surfer fromSurfer, ICommentable commentRegarding)
        {
            _id = Guid.NewGuid();
            CommentText = text;
            CommentingSurfer = fromSurfer;
            CommentDateTime = DateTime.UtcNow;

            Regarding = commentRegarding;
            commentRegarding.AddComment(this);
        }
    }
}
