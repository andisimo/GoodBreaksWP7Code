﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net;
using GoodBreaksTypes;
using GoodBreaksWP7.Utilities;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace GoodBreaksWP7.ViewModels
{
    public class BreakListViewModel : INotifyPropertyChanged
    {
        //private fields
        private ObservableCollection<Break> _breaks = new ObservableCollection<Break>();
        private int _currentSelectedIndex;
        
        //public properties
        public ObservableCollection<Break> Breaks
        {
            get { return _breaks; }
            set
            {
                if (_breaks != value)
                {
                    _breaks = value;
                    NotifyPropertyChanged("Breaks"); 
                }
            }
        }

        public bool IsDataLoaded { get; private set; }

        //methods
        public void LoadData()
        {
            string _url = string.Format("http://staginggoodbreaks.cloudapp.net:8080/api/{0}?{1}={2}", 
                "breaks","partitionKey","USWC");
            var request = (HttpWebRequest)WebRequest.Create(_url);
            request.Method = "GET";
            request.BeginGetResponse(new AsyncCallback(LoadDataCallback), request);
        }

        private void LoadDataCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            string responseString;
            var breakList = new List<Break>();

            using (var response = (HttpWebResponse)request.EndGetResponse(result))
            {
                using (Stream streamResponse = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(streamResponse);
                    responseString = reader.ReadToEnd();
                    reader.Close();
                }
            }

            if (responseString != null)
            {
                breakList = JsonConvert.DeserializeObject<List<Break>>(responseString);
            }

            UIThread.Invoke(() => {
                foreach (Break b in breakList)
                {
                    this.Breaks.Add(b);
                }
            });

            this.IsDataLoaded = true;
        }

        public void GetCommentsForCurrent(int index)
        {
            this._currentSelectedIndex = index;
            Break break1 = this.Breaks[_currentSelectedIndex];
            string _url = string.Format("http://staginggoodbreaks.cloudapp.net:8080/api/{0}?{1}={2}&{3}={4}",
                "breakcomments", "breakPK", break1.PartitionKey, "breakRK", break1.RowKey);
                var request = (HttpWebRequest)WebRequest.Create(_url);
                request.Method = "GET";
                request.BeginGetResponse(new AsyncCallback(GetCommentsCallback), request);
        }

        private void GetCommentsCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            string responseString;
            var commentList = new List<Comment>();

            using (var response = (HttpWebResponse)request.EndGetResponse(result))
            {
                using (Stream streamResponse = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(streamResponse);
                    responseString = reader.ReadToEnd();
                    reader.Close();
                }
            }

            if (responseString != null)
            {
                commentList = JsonConvert.DeserializeObject<List<Comment>>(responseString);
            }

            UIThread.Invoke(() =>
            {
                this.Breaks[_currentSelectedIndex].CommentsAboutMe.Comments.Clear();
                foreach (Comment c in commentList)
                {
                    this.Breaks[_currentSelectedIndex].CommentsAboutMe.Add(c);
                }
            });
        }

        public void GetSurfersAtCurrent(int index)
        {
            this._currentSelectedIndex = index;
            Break break1 = this.Breaks[_currentSelectedIndex];
            string _url = string.Format("http://staginggoodbreaks.cloudapp.net:8080/api/{0}?{1}={2}",
                "breaksurfers", "breakCompleteKey", break1.PartitionKey + "|" + break1.RowKey);
            var request = (HttpWebRequest)WebRequest.Create(_url);
            request.Method = "GET";
            request.BeginGetResponse(new AsyncCallback(GetSurfersAtCurrentCallback), request);
        }

        private void GetSurfersAtCurrentCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            string responseString;
            var surferList = new List<Surfer>();

            using (var response = (HttpWebResponse)request.EndGetResponse(result))
            {
                using (Stream streamResponse = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(streamResponse);
                    responseString = reader.ReadToEnd();
                    reader.Close();
                }
            }

            if (responseString != null)
            {
                surferList = JsonConvert.DeserializeObject<List<Surfer>>(responseString);
            }

            UIThread.Invoke(() =>
            {
                this.Breaks[_currentSelectedIndex].ThereNow.Clear();
                foreach (Surfer s in surferList)
                {
                    this.Breaks[_currentSelectedIndex].ThereNow.Add(s);
                }
            });
        }

        //INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
