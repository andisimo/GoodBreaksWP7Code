﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace GoodBreaks
{
    public class Break : ICommentable, INotifyPropertyChanged
    {
        //fields
        private Guid _id;
        private ICollection<Comment> _comments = new ObservableCollection<Comment>();
        private ICollection<Surfer> _thereNow = new ObservableCollection<Surfer>();

        //properties
        public Guid id
        {
            get { return _id; }
        }

        public string Name { get; set; }

        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public ICollection<Comment> Comments
        {
            get { return _comments; }
            set 
            {
                if (_comments != value)
                {
                    _comments = value;
                    NotifyPropertyChanged("Comments");
                }
            }
        }

        public ICollection<Surfer> ThereNow
        {
            get { return _thereNow; }
            set
            {
                if (_thereNow != value)
                {
                    _thereNow = value;
                    NotifyPropertyChanged("ThereNow");
                }
            }
        }

        //Constructors
        public Break(string breakName, double locLatitude, double locLongitude)
        {
            _id = Guid.NewGuid();
            Name = breakName;
            Latitude = locLatitude;
            Longitude = locLongitude;
        }

        //Methods
        public void AddComment(Comment comment)
        {
                Comments.Add(comment);
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            var handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
